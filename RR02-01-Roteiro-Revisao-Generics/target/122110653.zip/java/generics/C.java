package generics;

public class C<T> implements A<T> {
    @Override
    public void m(T obj) {
        return;
    }
}
