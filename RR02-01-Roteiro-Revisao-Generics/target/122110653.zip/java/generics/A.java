package generics;

public interface A<T extends Object> {
    public void m(T obj);
}
