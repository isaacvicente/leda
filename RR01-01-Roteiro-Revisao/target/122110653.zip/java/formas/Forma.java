package formas;

public interface Forma {
    public double calcularArea();
}
