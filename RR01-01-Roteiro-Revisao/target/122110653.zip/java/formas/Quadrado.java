package formas;

public class Quadrado extends Retangulo {
    public Quadrado(double lado) {
        super(lado, lado);
    }
}
